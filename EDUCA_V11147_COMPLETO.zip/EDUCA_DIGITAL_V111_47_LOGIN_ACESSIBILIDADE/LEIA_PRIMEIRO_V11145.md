# Educa+ Digital V111.45 — acessibilidade visível no celular

Continuação direta da V111.44.

## Correção
- Em celulares (até 600px) e tablets de toque (até 1024px), os controles **Acessibilidade** e **Ver guia novamente** aparecem logo após a saudação na central do aluno.
- Os dois botões ficam visíveis durante a rolagem da central e podem ser tocados, inclusive em telas pequenas.
- Em desktop/notebook, a posição original abaixo do Modo Livre é mantida.
- O guia de primeiro login de 6 passos continua apontando para os mesmos botões.
- Nenhuma atividade, conteúdo, LIA, banco, Worker ou configuração de voz foi alterada.

## Rodar no VS Code
```powershell
npm.cmd install
npm.cmd run dev
```
Abra http://localhost:8787 e teste a mesma conta em tamanho móvel e no computador.
Sem deploy remoto. Evite subir arquivos .env, .dev.vars, .venv, caches ou banco local.
