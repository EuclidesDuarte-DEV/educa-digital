# Educa+ Digital V111.46 — Hierarquia visual das atividades

Base: V111.45. Nenhuma alteração no banco de dados, API, LIA, fluxos de segurança, login ou Cloudflare.

## Mudanças
- Home: textos mais curtos, Pix como sugestão sem elementos redundantes, cartões com descrições diretas e Modo Livre menos chamativo.
- Trilhas: objetivo curto no topo e progresso discreto. Os cartões mostram somente número, título, descrição; "COMECE AQUI" aparece apenas na próxima etapa pendente e "CONCLUÍDA" nas finalizadas.
- Legibilidade: contrastes e tamanhos de fonte ajustados dentro do celular, com suporte a telas estreitas.
- Acessibilidade e "Ver guia novamente" continuam na posição responsiva criada na V111.45.
- Vídeos e atividades permanecem inalterados. O conteúdo de vídeo ainda depende das mídias já existentes no projeto.

## Executar
1. Extraia o ZIP em uma pasta nova.
2. No VS Code abra a pasta e rode `npm.cmd install` na primeira vez, depois `npm.cmd run dev`.
3. Abra a URL indicada no terminal (normalmente http://localhost:8787).
4. Faça login/cadastro, compare a Home e entre na trilha PIX. Faça também um teste no celular.

## Testes
Rode `npm.cmd test`. Publicação no GitHub/Cloudflare é uma etapa separada.
