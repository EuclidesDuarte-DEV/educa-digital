# Educa+ Digital — V111.47

**Base preservada:** V111.46. Esta atualização não altera as atividades, o banco D1, o motor LIA, a voz Kokoro ou os vídeos.

## Mudanças

1. **Entrada simplificada por telefone:** o formulário inicial pergunta somente o número com DDD. Para um número novo, cria um perfil de treino com nome técnico `Participante` (não exibido como saudação). Se o número já existe, encaminha à tela de código demonstrativo; não libera a sessão pelo cadastro. O formulário alternativo de criar conta também foi simplificado.
2. **Responsividade e textos maiores:** a ampliação não usa mais `zoom` sobre todo o aplicativo. Os cartões e a trilha crescem em altura; no modo `Letras muito grandes`, os cartões de assuntos ficam em uma coluna. A leitura vertical é preservada no celular simulado.
3. **Acessibilidade funcional:** leitura ativada por padrão em novas preferências, com narração de cada passo do guia após a primeira interação permitida pelo navegador. Pode ser desligada no painel; botão compacto de ouvir/parar no canto inferior. A preferência de contraste é aplicada sem filtros que distorçam fotos e vídeos.
4. **Ícones consistentes:** os controles de Acessibilidade e Ver guia novamente agora têm SVGs uniformes, tamanho mínimo 48 px e ficam mais afastados das atividades. No celular, existe um botão adicional de acessibilidade no cabeçalho da central, visível sem precisar rolar.
5. **Cache atualizado:** service worker `educa-cf11147-phone-only-responsive-a11y`.

## Executar no VS Code

```powershell
npm.cmd install
npm.cmd run dev
```

Abra o endereço exibido pelo Wrangler (normalmente `http://localhost:8787`). Se houver atualização antiga em cache, use `Ctrl + Shift + R`.

## Validação

- `npm test`: **159 testes passaram**.
- Verificação dos componentes com navegador em **320, 390, 768 e 1440 px**, nos modos de texto padrão, grande e muito grande: **sem rolagem horizontal nos componentes medidos**.
- Verificação em navegador do painel: contraste liga/desliga, tamanho de texto, preferência de voz, reprodução de orientação e fechamento.
- **Limite:** não foi possível abrir a aplicação completa através do servidor local no navegador automatizado neste ambiente; a validação visual foi feita com componentes isolados e emulações, não em aparelhos físicos. Antes de publicar, testar cadastro completo, pretest, atividades, guia e acessibilidade em Android/iPhone, tablet e desktop.

## Segurança e privacidade — muito importante

O número de telefone **não prova identidade**. Este projeto ainda utiliza **códigos demonstrativos exibidos na própria tela**, não enviados por SMS. Além disso, algumas APIs de progresso e perfil do protótipo usam o número como identificador sem sessão autenticada. **Não publicar como um sistema real de contas pessoais ou expor progresso/dados de usuários até implementar autenticação de produção**, gestão de sessões, controles de acesso, limitação de tentativas e políticas de privacidade. Para o futuro, avaliar confirmação de posse do aparelho com provedor, respeitando as orientações NIST SP 800-63B.

## Referências técnicas

- WCAG 2.2, texto 200% / reflow 320 CSS px: https://www.w3.org/TR/wcag/
- W3C — Reflow: https://www.w3.org/WAI/WCAG22/Understanding/reflow
- W3C — Acessibilidade cognitiva: https://www.w3.org/TR/coga-usable/
- MDN — SpeechSynthesis: https://developer.mozilla.org/pt-BR/docs/Web/API/SpeechSynthesis
- NIST — SP 800-63B: https://pages.nist.gov/800-63-4/sp800-63b.html

**Observação:** o funcionamento automático da voz depende de interação inicial do usuário e das vozes disponíveis no navegador; não é possível garantir reprodução imediata em todos os aparelhos sem essa autorização.
