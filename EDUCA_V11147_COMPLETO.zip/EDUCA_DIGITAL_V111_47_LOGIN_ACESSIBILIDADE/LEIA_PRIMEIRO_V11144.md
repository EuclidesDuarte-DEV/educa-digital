# Educa+ Digital — V111.44 | Guia no primeiro login

## O que mudou
- Preserva a V111.43 e seu guia existente de entrada e pré-teste.
- Após cadastro ou primeiro login, quando o usuário chega à tela de aprendizagem, inicia automaticamente **uma única vez por conta e navegador** o novo tutorial de 6 passos.
- Etapas: boas-vindas; escolher assunto/Pix; acessibilidade; Segurança e vídeos; Modo Livre com LIA; conclusão.
- Controles **Próximo, Voltar, Pular guia e Concluir**, com progresso visível e destaque sobre cada elemento real da interface.
- Acessibilidade e “Ver guia novamente” na central do treino, inclusive quando o cabeçalho está oculto no modo imersivo.
- O progresso do tutorial é salvo no armazenamento local, por identificador derivado da conta; não muda o banco D1.
- Quando o usuário toca no elemento destacado, o guia se encerra e a função é aberta.
- O guia existente “Como usar” da landing permanece disponível para visitantes.

## Testar no Windows / VS Code
1. Extraia o ZIP, abra a pasta principal no VS Code.
2. Execute `npm.cmd install`, depois `npm.cmd test`.
3. Execute `npm.cmd run dev` e abra o endereço impresso (geralmente `http://localhost:8787`).
4. Crie uma conta de teste ou entre em uma conta que ainda não viu o novo tour neste navegador.
5. Confira as seis etapas, **Voltar**, **Pular** e “Ver guia novamente”.
6. Ao recarregar e reentrar na conta, o tour não deve surgir automaticamente outra vez.
7. Teste a acessibilidade e o modo móvel. Voz e vídeo da LIA não são modificados.

**Não foi feito deploy Cloudflare ou migração D1.** Se o navegador mostrar uma versão antiga, use Ctrl+Shift+R e, se necessário, atualize o service worker antigo.
